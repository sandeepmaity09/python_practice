#!/usr/bin/python3

from distutils.core import setup

setup(
	name = 'print_lol',
	version = '1.0.0',
	py_modules = ['print_lol'],
	author = 'ghost',
	description = 'A Print Function for nested list',
)

