from distutils.core import setup

setup (
	name='listp',
	version='1.1.0',
	py_modules=['listp'],
	author='warmachine09',
	author_email='sm.sandeepmaity@gmail.com',
	url='http://www.listp.com',
	description='A module to work with lists'
	)