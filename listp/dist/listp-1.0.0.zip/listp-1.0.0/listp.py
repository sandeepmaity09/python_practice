#a program to recursively process the list

def print_lis(lis):
	for each_item in lis:
		if isinstance(each_item,list):
			print_lis(each_item)
		else:
			print each_item
